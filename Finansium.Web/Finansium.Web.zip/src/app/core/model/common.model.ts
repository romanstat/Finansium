export interface User {
    id: string;
    name: string;
    surname: string;
    patronymic: string;
    email: string;
    username: string;
    password: string;
  }
  