export const Constants = {
    ApiUrl: `https://localhost:7110`,
    AccessToken: `access_token`
}