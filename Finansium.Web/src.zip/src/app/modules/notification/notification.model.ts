export interface Notify {
  id: string;
  title: string;
  description: string;
  createdAt: Date;
  isViewed: boolean;
}
