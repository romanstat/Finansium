export interface News {
  id: string;
  title: string;
  description: string;
  createdAt: Date;
}
