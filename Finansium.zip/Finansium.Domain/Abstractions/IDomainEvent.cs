namespace Finansium.Domain.Abstractions;

public interface IDomainEvent : INotification
{
}
