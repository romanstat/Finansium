// Domain
global using Finansium.Domain.Abstractions;
global using Finansium.Domain.Users;

// Libs
global using MediatR;
