// Domain
global using Finansium.Domain.Users;
global using Finansium.Domain.Shared;
global using Finansium.Domain.Abstractions;

// Libs
global using MediatR;
