﻿namespace Finansium.Domain.Users;

public sealed class Permission : Entity
{
    public string Name { get; init; }
}
