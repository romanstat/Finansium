﻿namespace Finansium.Domain.Users;

public sealed class Permission
{
    public long Id { get; init; }

    public string Name { get; init; }
}
