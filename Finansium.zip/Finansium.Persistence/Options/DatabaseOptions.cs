namespace Finansium.Persistence.Options;

public class DatabaseOptions
{
    public required string ConnectionString { get; set; }
}
