﻿namespace Finansium.Persistence.Database;

internal static class Schemas
{
    public const string FinansiumDbContext = "core";
}
