﻿namespace Finansium.Application.Users.Queries.Get;

public sealed record GetUserQuery : IQuery<UserResponse>;
