﻿namespace Finansium.Application.Users.Commands.Login;

public sealed record TokenResponse(string AccessToken);
