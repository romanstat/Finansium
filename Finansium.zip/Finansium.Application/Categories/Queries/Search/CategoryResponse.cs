﻿namespace Finansium.Application.Categories.Queries.Search;

public sealed record CategoryResponse(Ulid Id, string Name, string Type);
