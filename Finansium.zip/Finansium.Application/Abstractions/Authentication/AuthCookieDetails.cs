﻿namespace Finansium.Application.Abstractions.Authentication;

public sealed record AuthCookieDetails(string Username, string RefreshToken);
