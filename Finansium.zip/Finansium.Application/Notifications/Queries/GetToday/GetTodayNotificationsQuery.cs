﻿namespace Finansium.Application.Notifications.Queries.GetToday;

public sealed record GetTodayNotificationsQuery : IQuery<IReadOnlyList<NotififcationResponse>>;
