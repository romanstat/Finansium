﻿namespace Finansium.Application.Notifications.Queries.GetUnreadCount;

public sealed record GetUnreadCountNotificationsQuery : IQuery<int>;
