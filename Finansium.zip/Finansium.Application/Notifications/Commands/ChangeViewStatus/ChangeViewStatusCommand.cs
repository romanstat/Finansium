﻿namespace Finansium.Application.Notifications.Commands.ChangeViewStatus;

public record ChangeViewStatusCommand(Ulid Id) : ICommand;
