﻿namespace Finansium.Application.Notifications.Commands.ViewedAll;

public sealed record ViewedAllNotificationsCommand : ICommand;
